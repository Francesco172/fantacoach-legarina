# FantaCoach nativa con Capacitor

Questa cartella è la base per creare APK Android o progetto iOS.

## Prima di compilare

1. Pubblica prima il backend FantaCoach online.
2. Apri `www/index.html`.
3. Sostituisci:

`https://INSERISCI-QUI-IL-TUO-BACKEND.onrender.com`

con l'indirizzo HTTPS reale del backend.

Il backend v0.5 include CORS per consentire all'app nativa di leggere i dati live.

## Android

```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

Serve Android Studio/Android SDK per creare APK o AAB.

## iOS

```bash
npm install
npx cap add ios
npx cap sync
npx cap open ios
```

Serve macOS con Xcode e firma Apple per installare su dispositivo reale.
